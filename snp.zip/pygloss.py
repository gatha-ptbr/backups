# -*- coding: utf-8 -*-
# https://www.tutorialspoint.com/execute_python3_online.php
import re
source = """"""
rx = re.compile("\{([^}]+)\}\{([^}]+)\}")
glossario = {}

for line in source.splitlines():
    if line.startswith("\pgloss"):
       res = re.search("\{([^}]+)\}\{([^}]+)\}", line)
       if not res:
       	  raise Exception("uops")
       # print(res.group(1) + "::" + %res.group(2))
       key = res.group(1)
       val = res.group(2)
       if key not in glossario:
       	  glossario[key] = []
       glossario[key].append(val)

pali_order = ['a', 'ā', 'i', 'ī', 'u', 'ū', 'e', 'o',
	      'k', 'kh', 'g', 'gh', 'ṅ',
	      'c', 'ch', 'j', 'jh', 'ñ',
	      'ṭ', 'ṭh', 'ḍ', 'ḍh', 'ṇ',
	      't', 'th', 'd', 'dh', 'n',
	      'p', 'ph', 'b', 'bh', 'm',
	      'y', 'r', 'l', 'v', 's', 'h', 'ḷ', 'ṁ', 'ṃ']
def wpali_order(w1, w2):
    # print(w1 + ":" + w2)
    if len(w1) == 0:
       return 1
    if len(w2) == 0:
       return -1

    if pali_order.index(w1[0]) == pali_order.index(w2[0]):
       if len(w1) > 1 and len(w2) > 1:
          if w1[0] in ['k', 'c', 'ṭ', 't', 'p']:
              if w1[1] == 'h' and w2[1] == 'h':
                 return 0
              else:
                return wpali_order(w1[1:], w2[1:])
          else:
            return wpali_order(w1[1:], w2[1:])
       else:
          if len(w1) == 1:
             return -1
          else:
             return 1
    else:
       if pali_order.index(w1[0]) < pali_order.index(w2[0]):
           return -1
       else:
           return 1

def merge(a, b):
    if len(a) == 0:
        return b
    elif len(b) == 0:
        return a
    res = wpali_order(a[0], b[0])
    if res == -1 or res == 0:
        return [a[0]] + merge(a[1:], b)
    else:
        return [b[0]] + merge(a, b[1:])
    
def mergesort(x):
    if len(x) < 2:
        return x
    else:
        h = len(x) // 2
        return merge(mergesort(x[:h]), mergesort(x[h:]))
        
def gloss_value(lst):
    return ", ".join(list(set(lst)))

print(glossario)
for key in mergesort(list(glossario.keys())):
    print("\\textit{" + key + "} & " + gloss_value(glossario[key]) + "\\\\")